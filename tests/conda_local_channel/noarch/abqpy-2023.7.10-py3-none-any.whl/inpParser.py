from __future__ import annotations

from abaqus.InputFileParser.InputFile import InputFile

__all__ = [
    "InputFile",
]
