from __future__ import annotations

from abaqus.Mdb.Mdb import Mdb
from abaqus.Session.Session import Session

session = Session()
mdb = Mdb()
