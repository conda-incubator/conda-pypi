from __future__ import annotations


def executeOnCaeStartup():
    """Execute onCaeStartup function in the relevant namespace."""
    # callStartupMethod('onCaeStartup')
    ...
