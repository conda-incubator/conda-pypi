from __future__ import annotations

from typing import List

from .ConnectorBehaviorOption import ConnectorBehaviorOption

ConnectorBehaviorOptionArray = List[ConnectorBehaviorOption]
