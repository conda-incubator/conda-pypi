from __future__ import annotations

from typing import List

from .ReferencePoint import ReferencePoint

ReferencePointArray = List[ReferencePoint]
