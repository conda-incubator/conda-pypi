from __future__ import annotations

from typing import List

from .ModelDot import ModelDot

ModelDotArray = List[ModelDot]
