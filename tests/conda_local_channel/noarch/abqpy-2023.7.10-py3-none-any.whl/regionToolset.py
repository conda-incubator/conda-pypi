from __future__ import annotations

from abaqus.Region.Region import Region

__all__ = [
    "Region",
]
