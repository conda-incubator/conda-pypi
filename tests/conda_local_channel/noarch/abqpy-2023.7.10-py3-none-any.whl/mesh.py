from __future__ import annotations

from abaqus.Mesh.ElemType import ElemType
from abaqusConstants import *

__all__ = [
    "ElemType",
]
