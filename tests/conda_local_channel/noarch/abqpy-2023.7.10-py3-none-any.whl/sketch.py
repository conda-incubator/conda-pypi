from __future__ import annotations


class FeatureSketch: ...


def Sketch(self, sheetSize: float = 200, gridSize: float = 5) -> FeatureSketch:
    return FeatureSketch()


def SketchTransform(): ...


__all__ = [
    "Sketch",
    "SketchTransform",
]
