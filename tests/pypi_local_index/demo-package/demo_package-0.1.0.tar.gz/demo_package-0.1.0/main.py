def main():
    print("Hello from demo-package!")


if __name__ == "__main__":
    main()
